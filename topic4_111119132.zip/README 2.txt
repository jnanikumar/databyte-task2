Problem Statement

Topic 4

- Training and Deploying a ML model
You are provided with the Iris dataset.
You are required to use 2 Machine Learning classification Algorithms
(you may use built-in libraries available).
- Deploy this model in web/app.
- There must be 4 user input parameters (sepal length, sepal width, petal length, petal
width) based on which you must predict the classification outcome in real time.
- There should be a functionality to train with more data, with the user providing further
data one by one. Button -> Add more Data. Users can include how many records he
wishes to enter over and above the existing dataset for the training phase.
- Functionality to choose which among 2 ML algorithms to train the current dataset on.
Button -> Train the current data.
Note : The model built should be retained and can be stored in local storage.
- Functionality to test the performance of the built model with user provided input for those
features. Given the set of inputs for the feature values from the user, the model should
be able to predict the target class of the flower, the user additionally selects which model
he/she wishes to use. Button -> Test the current model built.
Take care of the styling and other added functionalities of your website/app


tools and frameworks

my approach using streamlite for website development , and used numpy,sklearn,matplotlib.pyplot

logic

i used KNN,SVM AND Randomforest algorithm,with different aguments passed ,which can be altered in the localhost 
website


- Acknowledgements #how to run the code

streamlit will not support jupyter notebook(.ipynb) it only  accepts(.py) fromat file , to run this code
you need to use command prompt . in command prompt type ( streamlit run "location of the above .py file" )
 ,it will takeyou to the browser on which the website is hosted on a localhost
 #note:dont use the parantheses and also make sure streamlit should have been installed in your PC
